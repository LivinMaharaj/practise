import React from "react"

function Footer() {
    return ( <footer>
        This is the footer
    </footer>)
}

export default Footer