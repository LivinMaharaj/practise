
import React from "react"
const jokesData =[

    { 
        id : 1,
        punchLine: "I don't know, maybe plain"
        
    },
    {
        id: 2,
        question :"what's a flying dosa called?" ,
        punchLine: "I don't know, maybe plain"
    },
    {
        id: 3,
        question : "what's a flying dosa called?" ,
        punchLine: "I don't know, maybe plain"
    },
    {
        id: 4,
        question: "what's a flying dosa called?" ,
        punchLine: "I don't know, maybe plain"
    },
    {
        id: 5,
        question :"what's a flying dosa called?" ,
        punchLine: "I don't know, maybe plain"
    }
]

export default jokesData