const todosData =[
    {
        id: 1,
        text: "Empty garbage",
        completed: true
    },
    {
        id: 2,
        text: "Grocery shopping",
        completed: false
    },
    {
        id: 3,
        text: "Pack Sunday stuffs",
        completed: false
    },
    {
        id: 1,
        text: "Fold laundry",
        completed: false
    },
    {
        id: 1,
        text: "Water the plants",
        completed: false
    }
]

export default todosData