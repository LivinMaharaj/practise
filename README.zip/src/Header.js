import React from "react"

function Header() {
    return ( <header className="navbar">
        This is the header
    </header>)
}

export default Header