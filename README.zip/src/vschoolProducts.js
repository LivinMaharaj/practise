
const products =[
    {
    id : "1",
    name: "Pencil",
    price: 1,
    description: "The most forgiving tool"
    },
    {
        id : "2",
        name: "Coffee",
        price: 10,
        description: "Wake up !"
        },
        {
            id : "1",
            name: "Chai",
            price: 15,
            description: "An emotion"
            }

]

export default products